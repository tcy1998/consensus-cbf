% Author: Akash Patel (apatel435)
% Date: 6/6/19

function retval = cartpole_gen_next_ctrl(u)

    retval = u;

end

% Author: Akash Patel (apatel435)
% Date: 6/6/19

function clamped_u = cartpole_g(u)

    clamped_u = u;

end

% Author: Akash Patel (apatel435)
% Date: 6/6/19

function retval = cartpole_state_transform(x)

    sample_x = x;
    retval = sample_x;

end

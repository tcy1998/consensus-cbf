% Author: Akash Patel (apatel435)
% Date: 5/29/19

function is_task_complete = inv_pen_is_task_complete(x, t)

    is_task_complete = false;
    if t > 5;
      is_task_complete = true;
    end

end

% Author: Akash Patel (apatel435)
% Date: 5/29/19

function retval = inv_pen_filter_du(du)

    retval = du;

end

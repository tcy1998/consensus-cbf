% Author: Akash Patel (apatel435)
% Date: 5/29/19

function clamped_u = inv_pen_g(u)

    clamped_u = u;

end

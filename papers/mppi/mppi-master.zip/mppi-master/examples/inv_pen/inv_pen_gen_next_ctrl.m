% Author: Akash Patel (apatel435)
% Date: 5/29/19

function retval = inv_pen_gen_next_ctrl(u)

    retval = randn(1);

end

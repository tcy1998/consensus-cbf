% Author: Akash Patel (apatel435)
% Date: 5/29/19

function retval = inv_pen_control_transform(sample_x, sample_u, dt)

    u = sample_u;
    retval = u;

end

% Author: Akash Patel (apatel435)
% Date: 5/29/19

function retval = inv_pen_state_transform(x)

    sample_x = x;
    retval = sample_x;

end
